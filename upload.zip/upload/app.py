from flask import Flask, request, send_file
from PIL import Image
import io

app = Flask(__name__)

@app.route('/animate', methods=['POST'])
def animate():
    image1 = Image.open(request.files['image1'])
    image2 = Image.open(request.files['image2'])

    # Here you would include your AI logic to animate the images
    # For now, let's just blend them as a simple example
    blended = Image.blend(image1, image2, alpha=0.5)

    # Save to a bytes buffer to send back
    buf = io.BytesIO()
    blended.save(buf, format='PNG')
    buf.seek(0)
    
    return send_file(buf, mimetype='image/png')

if __name__ == '__main__':
    app.run(debug=True)
